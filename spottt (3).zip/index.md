| seq | method | status | mime | size | url |
|---:|:--|:--:|:--|--:|:--|
| 17 | GET | 200 | text/javascript | 3695 | chrome-extension://cjpalhdlnbpafiamejdnhcphjbkeiagm/web_accessible_resources/google-analytics_analytics.js?secret=mspl3q |
| 26 | GET | 200 | application/javascript | 0 | https://spodownloader.com/script/axios.min.js |
| 27 | GET | 200 | application/javascript | 0 | https://spodownloader.com/script/index.js |
| 28 | GET | 200 | application/javascript | 0 | https://spodownloader.com/script/index.umd.js |
| 31 | GET | 200 | application/json | 633 | https://api.fabdl.com/spotify/get?url=https%3A%2F%2Fopen.spotify.com%2Ftrack%2F5WOSNVChcadlsCRiqXE45K |
| 34 | GET | 200 | application/json | 566 | https://api.fabdl.com/spotify/mp3-convert-task/15750868/5WOSNVChcadlsCRiqXE45K |
| 35 | GET | 200 | application/json | 571 | https://api.fabdl.com/spotify/mp3-convert-progress/1fe6c33f091524c33c28ee818efcc3f4 |
